package bean;

public class Teacher {
private int tid;
private String tname;
private String mail1;
private String pass1;
public int getTid() {
	return tid;
}
public void setTid(int tid) {
	this.tid = tid;
}
public String getTname() {
	return tname;
}
public void setTname(String tname) {
	this.tname = tname;
}
public String getMail1() {
	return mail1;
}
public void setMail1(String mail1) {
	this.mail1 = mail1;
}
public String getPass1() {
	return pass1;
}
public void setPass1(String pass1) {
	this.pass1 = pass1;
}





}
